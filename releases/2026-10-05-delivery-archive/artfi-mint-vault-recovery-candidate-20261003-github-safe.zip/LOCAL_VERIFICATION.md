# Final local candidate after bounded review fixes

Date: 2026-10-03. This supersedes the first candidate's local report for the final source. The original `723a48d` commit, patch and evidence remain preserved. No deployment or final integrated-head CI acceptance is asserted.

## Commits and integration

Isolated worktree: `/workspace/shared/artfi-mint-vault-recovery` (clean).

Apply all three commits in this order from local base `fd24ada5c245547ddbf292a9a9a15aef0891639b`:

1. `723a48d004f89bb605fbe4b494967611a17a04eb` — original bounded mint/Vault recovery.
2. `1417362b240074d6fc283a65a7d11462e998b546` — prohibit submission logging before canonical receipt proof.
3. `7e0c7c059673e98982570627c1422a2a1bf3fa1d` — repeated Vault creation, explicit role continuation, connected-state retirement and initial operator-session recovery.

Final tree: `4b89578241b369f4f1cc47e0f0da8021d9709b58`.

Artifacts:

- `fd24-to-7e0c7c0-mint-vault-recovery.patch`: complete three-commit series. SHA-256 `210222f510ad8af8cb64b0c99326016d68dfc6b602f2a22a1328ae075489d65f`.
- `723a-to-7e0c7c0-review-fixes.patch`: only the two additional commits. SHA-256 `e23bf03c34381e19839af52f11408565ed24780d663335fd8c6f764d68617090`.
- `final-source.diff`: complete source delta from the supplied base. SHA-256 `6a85ca88c743275107e3d93409c568f62a777062b6cff10ffacc72ca2476a16a`.

The complete candidate changes 13 frontend/helper/test/fixture files. No contract/API implementation, shared existing market/DAO transaction helper, dependency lockfile, CI configuration, STATUS declaration, infrastructure, credential or deployment setting changed. The intended integration parent is the final merged #135 main; the delivery coordinator supplied real main `bd67d0ffc9634f5a50430cfdce9fd37dcc4be2bb` for that subsequent integration. This worktree does not claim tests of the future integrated tree.

## Review findings closed

### Canonical Vault submission hash

The original candidate's automatic path waited for chain proof, but its manual logging retry could still attach an unconfirmed original hash after a timeout. Because the existing API binds one hash per intent, repricing could then leave the canonical hash unable to be recorded.

The fix removes all three pre-confirmation assignments of `creationHash`/`submissionPending`. Pending identity stays in the original public transaction journal. Only successful receipt plus the full factory/request/asset/name/admin/role getter proof sets the canonical logging fields. UI availability and the real HTTP entry share the same `vaultCreationSubmission` / `recordConfirmedVaultCreation` guard. Getter-only recovery does not manufacture a receipt hash. A regression runs the real session, receipt/replacement and logging helpers through pending timeout → manual retry with zero API calls → repriced successful receipt → one canonical hash submission. No-hash state remains unresolved rather than being cleared for retry.

### A second Vault after completion

Completed setup no longer permanently prevents another asset from being configured. “Prepare another Vault” is explicit and is available only for a complete, idle, readable setup with no unresolved request. It saves the old confirmed configuration, intent, canonical creation hash, fraction token and unfinished API logging evidence before the active form is replaced. The saved record retains a separate submission-retry action and exact chain links. The manual form and owned-NFT selector both work for the new operation, including a new mint's chain/collection/token continuation.

### Existing fractionalizer role handoff

A configured fractionalizer B can explicitly select “Review and continue Vault” after A deposits the NFT. A confirmed public continuation is discovery/configuration only; it never substitutes for chain authority. The action independently rechecks factory request and asset mapping, Vault name/admin/roles, custody, original depositor, no existing fraction token, and B's actual `FRACTIONALIZER_ROLE`.

B receives a separate wallet-bound journal. A's journal and late transaction results stay with A. `depositorAddress` remains A. Participating wallet journals are checked from both live state and durable storage after asynchronous reads and immediately before another wallet prompt. Unresolved, unavailable or missing records do not become permission to retry. Completed-token review can restore the verified final state to a participant without granting transaction rights.

The extra registrar prerequisite introduced by the first candidate was removed from existing Vault chain actions. Creation/intent preparation and protected API writes keep their operator-session requirements. Exact-token approval and deposit still require current NFT ownership and exact approval as applicable; fraction issuance requires current Vault custody, no issued fractions and the current Vault fractionalizer role. No ordinary login, registration or new background-wallet permission was added. Tests exercise B with a true negative registrar check and positive fractionalizer role, plus unauthorized C refusal before an issuance request.

### Connecting-state retirement

DAO's actual keyed view now includes `isConnected`, matching the mint boundary. A connecting state can retain the previous address/chain; it now retires the previous view even in that case. The shared key helper's regression covers connected → connecting with unchanged address and chain.

### Initial operator HTTP 401

Public deployment discovery and operator-session lookup now resolve independently. A real HTTP 401 is an unauthenticated session, so a readable factory config remains available and successful operator verification enables creation without reload. Other session-service failures remain visible. A role-only B can still use the independently verified public factory config and current Vault role. Unit tests exercise the real access-loading helper; browser cases use actual HTTP 401 responses for both first verification and B/C handoff.

These fixes preserve the original nine-defect scope and role model. They add no Stage 2, economics, Oracle, contract policy, governance or deployment prerequisite.

## Final-source checks

| Check | Actual final result |
| --- | --- |
| Full web unit suite, `./node_modules/.bin/vitest run src` from `apps/web` | 498 passed in 41 files; `web-unit.log` |
| Full web ESLint, `./node_modules/.bin/eslint .` | Exit 0 |
| Web TypeScript, `./node_modules/.bin/tsc --noEmit` | Exit 0 |
| Production build, `./node_modules/.bin/next build --webpack` | Exit 0; 35 static pages generated; `webpack-build.log` |
| Changed-file Prettier | Passed |
| Staged source whitespace check | Passed |
| Secret pattern scan with all final files staged | Passed across 530 repository files |
| Isolated setup browser test collection | 27 tests in one file; `browser-collection.log` |

The final production build still emits the recorded optional/dependency warnings for MetaMask async storage, `pino-pretty`, and a dynamic `ox` dependency. It completes successfully. Dependency versions and settings were not changed.

The final 27 browser cases include the original recovery coverage plus explicit second-NFT configuration with retained old logging evidence, B with HTTP 401/no registrar continuing issuance, unauthorized C refusal, and first HTTP 401 → verification → creation without reload. The actual-ABI fixture unit suite remains included in the 498 passing tests. Independent static review reported no remaining blocking finding in the bounded final diff; that is not browser execution evidence.

## Unrun and operational limits

All 27 browser assertions remain unrun locally. The previously documented Chromium launch fault occurred before page creation: `process_singleton_posix.cc:297 socket() failed: Operation not permitted (1)`. As directed, there were no further launch retries, escalation attempts or sandbox/security workarounds during these review fixes. The original launch evidence remains in the first delivery's `browser-launch-blocker.md`.

Final integrated-head CI and connected browser execution remain required after integration. No live wallet/RPC transaction, real-asset operation, production access, push, merge or deployment was performed by this task. Existing contract/API implementations were unchanged; no new live contract/API integration pass is claimed.

Local checks used already-installed dependency binaries through temporary symlinks because the pnpm wrapper attempted an unavailable home-store operation. Webpack was used because those external symlinks are not accepted by local Turbopack. Symlinks were removed after verification. The final worktree is clean, and no test server remains.

## Coordinator integration on merged PR #135

The three reviewed commits were applied without conflicts onto local snapshot `6b91aed681b9abc3e78ea6c34334ff6a366d21f4`, whose complete remote tree is merged main `bd67d0ffc9634f5a50430cfdce9fd37dcc4be2bb` (`c427fcb4995dd41716e723a8f304e51b1c0601b7`). This preserves the final native-order, public-origin, session, responsive-layout and CTYun SSH-port fixes from PR #135 and PR #134.

The integrated candidate passes all workspace lint, typecheck, unit tests, default Next/Turbopack production build, formatting and secret checks. The web suite executes 518 tests in 41 files. The existing market browser command collects 46 cases: 19 retained cases and 27 new setup/recovery cases. Actual browser execution for the new slice remains pending on its exact-head CI. The independent portfolio read-model correction is a separate PR and is not included in this source snapshot.

Independent review covered the actual components and found five concrete defects that were repaired before this integration: premature logging of an unconfirmed creation hash, repeated Vault creation, explicit role-B continuation and an inappropriate registrar prerequisite, connecting-state retirement, and public config loading after an initial authentication 401. The final review reports no remaining blocking finding within this bounded scope. Creation/protected API permissions remain as before; later Vault chain actions enforce their original owner/fractionalizer roles rather than registrar identity.

### Final base update

The final candidate additionally preserves merged portfolio PR #136. Its real base is `0c73075d72ce2080d2934a629d1b8b8995104e76`, verified tree `dc1f554b184694ba2d2fd1e5ee23d258b1ebb871`. All 13 mint/Vault source blobs are unchanged by this base update. The local integrated candidate was rechecked with workspace lint, typecheck, tests (518 web tests), default production build, formatting and secret scan, all passing. The remote candidate will use this real merge commit as its parent; synthetic local history will not be pushed.
