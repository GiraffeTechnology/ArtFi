# Mint/Vault CI follow-up

PR #137 head d3d5b7919a13c7252b6f00366b39df4f06df2717, base 0c73075d72ce2080d2934a629d1b8b8995104e76, verified tree ed084dbb2ffcc45fe22d1319be70f33a13d6e371. All 13 candidate blobs confirmed. The second exact-head CI run is executing all eight jobs, including 46 connected market cases. The first run had six successful jobs; its two browser failures are documented in CI_FOLLOWUP.md. Local corrected-source checks pass. No merge or deployment is claimed.
