# Remaining PR135 runtime corrections

Head9a4da9e9 run37105269398 completed with6 successful jobs and2 failures: market17/19 and session4/5. Native order cards inherited sticky positioning, physically covering the later settlement button; market-local transaction panels now stay in document flow. Existing normal click checks remain, and public-link reload checks now verify normal button hit testing on desktop and390px fractions, without dispatching a transaction.

The mobile fraction session flow already completed explicit publication, immutable retry, direct SQL read, linked load and reload. Its exact getByLabel failed because controlled textarea default text includes the restored JSON. The test now locates the textbox by its exact accessible name; complete intent/signature and390px assertions remain. No runtime authentication or restoration check was removed.

Local workspace lint, types, unit tests, default build, formatting and secret scan passed. Actual corrected browser execution remains pending on the next exact-head CI. PRbody metadata updates are blocked by automatic review after one evidence-backed retry; current code and CI facts must be read from GitHub head/jobs.
