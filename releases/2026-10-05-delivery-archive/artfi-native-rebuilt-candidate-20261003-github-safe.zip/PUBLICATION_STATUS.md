# Native orders and wallet sessions: verified delivery

PR: https://github.com/GiraffeTechnology/ArtFi/pull/135

Validated PR head: `cd41b21be7659fb7fe3f1448dcd9dbf1f2b9c7b2`.
Merge commit: `bd67d0ffc9634f5a50430cfdce9fd37dcc4be2bb`.
Verified tree for both: `c427fcb4995dd41716e723a8f304e51b1c0601b7`.
Exact-head quality run: https://github.com/GiraffeTechnology/ArtFi/actions/runs/37106702502

All eight jobs completed successfully: web, API, contracts, migration, browser, market-browser, Oracle-browser and session-browser. No job was skipped.

- Web: 449 unit tests; API client: 5, market mirror: 49, wallet extension: 6. Lint, types, production build, schema and secret checks passed.
- Contracts: 136 passed, no skips.
- Native market/receipt/recovery browser: 19 passed, including normal desktop/mobile hit testing, navigation/reload, interrupted authorization and late receipt handling.
- Real Next-to-Go-to-MySQL session/publication browser: 5 passed, including explicit login, private durable cookies, refresh rotation/replay/logout, unauthorized and mismatched seller rejection, whole publication and mobile fractional publication/reload.
- Oracle browser: 14 passed.
- General browser: 182 passed, 2 existing skips. These skips are not claimed as executed acceptance.
- All 11 new SQL order/session integration cases executed and passed, including single-use and refresh concurrency, durable restart/logout/replay, transaction rollback, immutable publication and 21st-order pagination.

The ordinary login grants no transaction authority. The existing sale signature and explicit publication are required, with independent seller/session and internal-verifier checks. The public Origin and Host are compared exactly to the configured application authority; untrusted forwarded headers are not authoritative. No live wallet transaction, production credential configuration or deployment occurred.

The merged scope is 63 files. CTYun TCP port 443 remains reserved for SSH, and that restriction is not extended to SIN. Deployment remains for the existing artfi control task after the remaining mint/Vault and small read-model work is complete. The unchanged PNG stays in the exact remote tree; local recovery source omits that binary and records its original SHA.

The PR body remains an earlier snapshot because automatic review rejected its metadata update twice. The verified GitHub commit and job evidence above records the final outcome. Postmerge main run [37107013072](https://github.com/GiraffeTechnology/ArtFi/actions/runs/37107013072) also completed successfully with all eight jobs executed and passed.
