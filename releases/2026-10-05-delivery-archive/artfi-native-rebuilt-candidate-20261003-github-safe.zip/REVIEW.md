# ArtFi rebuilt order/session boundary review

Reviewed the current reconstructed working tree at `/workspace/shared/artfi-native-rebuilt` against local snapshot `33a9d7e7e5885173585df8557cc33a4118073ce3` (remote main `687894a9` per assignment). This is not a verification of the lost original 63-file candidate. Scope was the native order API/BFF, ordinary wallet sessions, signatures, and receipt/session integration. No repository edits or remote actions were made.

## Result after targeted correction

No outstanding blocking finding from this focused pass. The sole P2 below is **closed** in the corrected working tree. Only that correction was re-reviewed; the broader test results below describe the initial pass.

Recheck evidence: executed both actual extracted Check transaction handlers with the real source `currentOperation` and `reconcileCurrentView` helpers. Waited until refetches had actually started, then retired the captured operation and changed the visible order. Both delayed success and delayed failure left order B at `idle`; neither published stale completion/error. With the operation still current, order A correctly reached `filled`. All six handler-harness scenarios passed, process exit 0. This remains a deterministic source-handler check, not browser end-to-end evidence.

The correction uses a captured live `isCurrent` function (`use-market-transactions.ts:200`), checks it after the receipt and post-receipt refresh await and before error publication (`current-operation.ts:18`), and is used by both actual handlers (`whole-artwork-listing.tsx:970`, `fraction-listing.tsx:1226`).

## Closed correctness finding

**P2, fixed — a reconciled old order could mark newly selected terms as settled.**

- Original files/lines before correction: `apps/web/src/components/whole-artwork-listing.tsx:979`, `apps/web/src/components/fraction-listing.tsx:1238`; supporting snapshot at `apps/web/src/lib/use-market-transactions.ts:194`.
- Baseline: pending receipts must retain their original intent attribution; stale async terms must not report completion for another order.
- Evidence: `reconcile()` returns `current` as a boolean before either listing awaits its chain refetches. During those refetches, the native order panel still permits Load order / Refresh orders (`native-order-panel.tsx:378`, `:316`). Selection changes retire the operation and clear the UI, but the handler later tests its saved boolean and captured old `pastedDigest`, then sets `filled` on the current screen.
- Reproducer: start Check transaction for pending fill A; let its successful receipt resolve; hold the subsequent refetch promises; load order B (or refresh/clear terms); resolve those refetches. Both handlers produce `filling(A) → idle(B) → filled(B)`. Confirmed by executing the actual extracted handlers through TypeScript transpilation with deferred refetches. This reproducer exercises the source handlers, not a browser rendering test.
- Applied correction: preserve a live operation-currentness check through all post-receipt awaits and return without updating UI if the original terms were retired. Receipt journal reconciliation remains independent of login and preserves original intent attribution. No unauthorized transaction was observed from this defect; the defect was false settlement feedback.

No other high-confidence blocking defect was found in this focused pass. The inspected paths preserve the original sale signature, separate seller session/indexer checks, immutable replay priority, persistence-unavailable errors, durable single-use challenge/refresh/logout semantics, and compare-and-swap receipt reconciliation.

## Checks and limits

- Passed: 129 focused Vitest tests across 11 files covering auth/BFF/session races, native orders, market signatures, preflight, operation retirement, and transaction journals.
- Passed: eight top-level Go non-SQL tests selected for signed orders and user auth, including their subtests.
- Unverified: all 11 selected MySQL integration tests skipped because `ARTFI_INTEGRATION_MYSQL_DSN` was absent (eight wallet-auth and three native-order tests). Skips are not passes.
- Unverified: real browser/Next/Go/MySQL integration; local Chromium EPERM and missing MySQL were already established by the owner. Unfinished e2e-session scaffold was excluded from this review.
- Retained documented limits: same-tab market wallet lock, no full cross-tab transaction mutex; Web Locks serialize cookie writers but explicit logout/confirmed wallet change targets the current shared cookie.
