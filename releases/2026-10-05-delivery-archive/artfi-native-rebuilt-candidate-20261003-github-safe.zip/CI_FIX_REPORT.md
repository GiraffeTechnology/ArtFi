# PR135 CI follow-up verification

Initial head adaf3a6981d97a2550596c04a37b22005016342a, run37104225740: API, migration, contracts, oracle-browser and browser passed. Contracts136, Oracle14 and general182 passed with2 existing skips. All11 new MySQL order/session cases executed and passed. Web, market-browser and session-browser failed.

The public-origin bug was reproduced with the installed NextRequest normalizing127.0.0.1 tolocalhost. The corrected route requires the configured exact browser Origin and public Host/effective port, ignores untrusted forwarded headers, and rejects cross-site or malformed bindings. Existing seller/session/indexer/signature checks remain.19 additional route cases cover real NextRequest and positive/negative boundaries.

The installed viem ENS lookup used by RainbowKit calls reverseWithGateways; the strict read-only fixture now encodes an absent ENS name and an actual viem action exercises it. Unknown selectors and transaction submissions remain errors. The responsive login assertion selects the visible element; the API-client test retains exact query assertions without unsupported DOM iteration typing.

Fresh local full-workspace lint, typecheck and test passed: web449, API-client5, market-mirror49, wallet-extension6. Full-workspace build, formatting and secret scan passed. No browser runtime pass is claimed locally. The next exact-head8-job CI must execute again before merge.
