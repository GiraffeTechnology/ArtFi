# Verified portfolio corrections

PR #136 merged as 0c73075d72ce2080d2934a629d1b8b8995104e76, tree dc1f554b184694ba2d2fd1e5ee23d258b1ebb871. PR head 69ff272d6401e8cdb849eba4c7d2bcfa3c90f6db passed all eight jobs in run 37107869894. Merged main passed all eight jobs in run 37108274919. The real MySQL confirmation replay/restart test executed and passed; raw balances, cache invalidation, removed-first status and duplicate-free projection were checked. No deployment or live-chain action occurred.
