# ArtFi coding handoff

Start with `HANDOFF_INDEX.md`, then forward `FORWARD_TO_ARTFI_CONTROL.txt` with this ZIP and the existing Wallet DApp ZIP to the original deployment task. This package has not been directly sent to that task and does not claim either site has been deployed.

`RELEASE_MANIFEST.json` fixes the ArtFi and Wallet versions. `VALIDATION.md` and `CI_EVIDENCE.json` record the completed code checks. `DEPLOYMENT_HANDOFF.md` and the updated deployment contract in `source/docs/` describe the existing build and routing requirements. `ACCEPTANCE_RECORD.md` remains blank for the actual runtime observations.

`source/` contains 529 verified tracked files with executable modes retained. One unchanged PNG is unavailable locally and is explicitly recorded in `SOURCE_MANIFEST.json`; it remains in the full remote tree. Build from the pinned complete Git checkout. `SHA256SUMS` verifies every included file except itself. The Wallet ZIP is referenced, not duplicated or repackaged.
