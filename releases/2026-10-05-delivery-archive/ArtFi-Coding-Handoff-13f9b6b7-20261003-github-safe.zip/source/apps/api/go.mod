module github.com/GiraffeTechnology/ArtFi/apps/api

go 1.26.0

toolchain go1.26.5

require (
	github.com/go-sql-driver/mysql v1.10.1
	github.com/redis/go-redis/v9 v9.22.0
)

require (
	filippo.io/edwards25519 v1.2.0 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	go.uber.org/atomic v1.11.0 // indirect
	golang.org/x/sys v0.30.0 // indirect
)
