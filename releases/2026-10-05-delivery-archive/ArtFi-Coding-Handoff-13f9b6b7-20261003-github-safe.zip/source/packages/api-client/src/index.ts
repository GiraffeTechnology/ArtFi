import type { components } from "./schema";

export type ArtFiConfig = components["schemas"]["Config"];
export type Asset = components["schemas"]["Asset"];
export type MintedNFT = components["schemas"]["MintedNFT"];
export type Project = components["schemas"]["Project"];
export type Portfolio = components["schemas"]["Portfolio"];
export type NativeSignedOrder = components["schemas"]["NativeSignedOrder"];
export type Problem = components["schemas"]["Problem"];

export class ArtFiAPIError extends Error {
  constructor(public readonly problem: Problem) {
    super(problem.detail);
    this.name = "ArtFiAPIError";
  }
}

export function createArtFiClient(
  baseURL: string,
  fetcher: typeof fetch = fetch,
) {
  const request = async <T>(path: string): Promise<T> => {
    const response = await fetcher(new URL(path, baseURL), {
      headers: { Accept: "application/json, application/problem+json" },
    });
    if (!response.ok) {
      throw new ArtFiAPIError((await response.json()) as Problem);
    }
    return (await response.json()) as T;
  };

  return {
    nativeOrders: (
      filters: {
        kind?: "whole" | "fraction";
        chainId?: 560048;
        marketAddress?: string;
        assetAddress?: string;
        tokenId?: string;
        sellerAddress?: string;
        page?: number;
        pageSize?: number;
      } = {},
    ) => {
      const query = new URLSearchParams(
        Object.entries(filters)
          .filter(([, value]) => value !== undefined)
          .map(([key, value]) => [key, String(value)]),
      );
      return request<{
        data: NativeSignedOrder[];
        total: number;
        page: number;
        pageSize: number;
      }>(`/v1/orders?${query}`);
    },
    nativeOrder: (intentHash: string, chainId: 560048, marketAddress: string) =>
      request<NativeSignedOrder>(
        `/v1/orders/${encodeURIComponent(intentHash)}?${new URLSearchParams({ chainId: String(chainId), marketAddress })}`,
      ),
    config: () => request<ArtFiConfig>("/v1/config"),
    assets: () => request<{ data: Asset[]; total: number }>("/v1/assets"),
    mintedNFTs: () =>
      request<{ data: MintedNFT[]; total: number; chainId: 560048 }>(
        "/v1/nfts",
      ),
    asset: (slug: string) =>
      request<Asset>(`/v1/assets/${encodeURIComponent(slug)}`),
    projects: () => request<{ data: Project[]; total: number }>("/v1/projects"),
    portfolio: (address: string) =>
      request<Portfolio>(`/v1/portfolio/${encodeURIComponent(address)}`),
  };
}
