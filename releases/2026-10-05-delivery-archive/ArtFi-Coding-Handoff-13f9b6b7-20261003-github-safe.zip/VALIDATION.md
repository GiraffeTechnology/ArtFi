# Final code validation

ArtFi is fixed at commit `13f9b6b774fd7ba6010cd7a500574074d1ac37d3`, tree `c82647bcccdea444bec0a09c65b9e13ffafa0b24`.

- Final PR #138 head: `96a1fdc95e49360bd98e2eb299dd7eb15b89132e`.
- PR quality: https://github.com/GiraffeTechnology/ArtFi/actions/runs/37110138584 — all eight jobs succeeded.
- Final-main quality: https://github.com/GiraffeTechnology/ArtFi/actions/runs/37110585078 — all eight jobs succeeded.

The final-main run executed 518 web unit tests, 5 API-client tests, 49 market-mirror tests, 6 existing wallet-extension tests, and 136 contract tests. Browser results: 46 market/recovery cases, 5 real Next → Go → MySQL session/publication cases, 14 Oracle cases, and 182 general cases passed. The migration job executed the 12 new order/session/portfolio MySQL cases, including replay, restart, concurrency, rollback, cache invalidation and removal precedence. Lint, types, production build, schema and secret checks also passed.

The general suite retains two skipped desktop/mobile variants of the configured charity-edition supply test because its editions address was not configured for that suite. No new recovery case was skipped. An earlier PR #137 run had one existing mobile operations-status test pass on retry; that historical flaky result is disclosed. The final PR #138 and final-main runs both completed the general suite with 182 direct passes and the two existing skips, without flaky results. Retry settings were not changed.

Delivered changes preserve all three product lines. They finish durable native order publication/readback and ordinary wallet sessions; exact receipt/approval recovery; mint/Vault interruption, logging, repeated-asset and configured-role continuation; and the two bounded portfolio read-model corrections. The final deployment document removes obsolete Sepolia and blanket no-native-trading instructions while preserving the actual interfaces, existing topology and CTYun SSH reservation.

No application deployment, live provider/device acceptance, production secret configuration, mainnet transaction or real-asset operation was performed. Docker image creation with actual environment bindings and the deployed-site checks remain for the existing deployment task. `ACCEPTANCE_RECORD.md` intentionally leaves those observations unverified.

Use the fixed Git checkout as the complete build source. This ZIP contains all 529 locally available tracked source files, verifies their Git blob hashes and records the entire 530-blob remote tree. The unchanged `apps/web/public/brand/giraffe-head-color.png` remains on GitHub at blob `060e6d027e35306ad97c7197c7821564f311393f`; the connector could not materialize that binary locally, so it is explicitly omitted here. It was present in the full GitHub checkout used by CI and is not deleted or replaced by this delivery.
