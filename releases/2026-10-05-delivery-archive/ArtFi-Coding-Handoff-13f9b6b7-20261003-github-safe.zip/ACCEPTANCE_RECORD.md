# Deployment acceptance record

Use this form after the existing deployment task acts. The coding handoff leaves every runtime result below unverified. Do not fill a result from a fixture, code presence or a previous build.

- ArtFi deployed commit and image digest:
- Wallet DApp deployment commit and package SHA-256:
- Public URLs and observed build revision:
- SIN UI/chain service and CTYun API/MySQL bridge bindings, with secrets omitted:
- CTYun SSH on TCP443 preserved; actual approved web/bridge allocation:
- Existing Qwen operations and monitoring status:

| Workflow | Actual configured result and evidence | Open issue, if any |
| --- | --- | --- |
| Three public entry routes and static assets, desktop/mobile | Unverified | |
| NFT/CCHS/OpenSea links and configured charity holder access | Unverified | |
| Ordinary connect/login/reload/refresh/logout | Unverified | |
| Whole receipt sign/publish/public lookup/settlement and read-only recovery | Unverified | |
| Oracle exact-asset identity/status/disagreement/unavailability | Unverified | |
| Mint rejection/retry, receipt and logging recovery | Unverified | |
| Exact owned NFT, Vault, approval, deposit, issuance and holdings | Unverified | |
| Second NFT and configured fractionalizer B continuation; unauthorized C rejection | Unverified | |
| Fractional order publication/partial fill/withdrawal/recovery | Unverified | |
| DAO delegation/proposal/vote/queue/execute using existing test authority | Unverified | |
| Indexed base-unit display and confirmation/removal history | Unverified | |
| Wallet DApp provider/device and target-origin behavior | Unverified | |

Record only actions covered by the deployment task's existing authorization. This form adds no new production credential, mainnet or real-value transaction authority. Return the actual results to the delivery owner for final acceptance.
