# ArtFi handoff to the existing deployment task

Coding and CI are complete at ArtFi commit `13f9b6b774fd7ba6010cd7a500574074d1ac37d3`, tree `c82647bcccdea444bec0a09c65b9e13ffafa0b24`. PR run 37110138584 and final-main run 37110585078 each executed all eight jobs successfully. This package is ready to forward to the existing deployment task; it has not been sent directly to that task, deployed, or accepted on the live sites.

## Product and environment

Deliver the existing three sections at `https://io.artcch.com`: digital NFTs without physical backing, linked to CCHS with OpenSea as the primary marketplace; whole-artwork receipt/voucher tokens using ERC-8415; and the original fractional trading and DAO workflows. No Stage 2 or independent-wallet completion prerequisite is added.

Use the existing ArtFi deployment task and the established infrastructure: SIN for UI and chain execution; CTYun abcdyi and MySQL for backend/data services; the existing bridge and Qwen API operations with 24-hour supervision. Inspect existing ArtFi configuration to reuse the appropriate old build and dependencies. Establish the relation of any `artcch.com` build to ArtFi before replacing it. Do not replace an independent site merely because its domain is related.

On CTYun, TCP port 443 is reserved for SSH. No HTTP, HTTPS, reverse proxy or TLS listener may take that port, and SSH must remain in place. Resolve web/bridge ports from existing operations configuration; this handoff specifies no replacement port. The CTYun reservation does not extend to SIN.

## Source, build and routing contract

Use the final pinned Git commit from `GiraffeTechnology/ArtFi`, not an unversioned image or a synthetic local snapshot. The remote tree retains every original binary asset. Recovery ZIPs contain source, patches and manifests but explicitly omit one unchanged connector-unreadable PNG; the complete remote checkout is the build authority.

- Web: repository-root build context, `apps/web/Dockerfile`; the unprivileged standalone runtime listens on container port 3000. Set `ARTFI_BUILD_SHA` to the final full commit SHA. `NEXT_PUBLIC_*` values are build arguments embedded in the browser bundle; changing runtime environment alone will not change them.
- API: `apps/api/Dockerfile`, built with the `apps/api` context; the existing `ARTFI_API_ADDR` controls the private listener. Public SIN `/v1/*` routing reaches the CTYun API through the established bridge, not an assumed local API process.
- Preserve the configured public Host and effective port at the UI proxy. Native order publication independently verifies that Host and the exact browser Origin. Client-supplied forwarded headers do not establish that authority.
- The canonical public origin is `https://io.artcch.com`. Keep Next `ARTFI_WEB_URL` and Go `ARTFI_WEB_ORIGIN` consistent. Next server adapters use the existing `ARTFI_API_URL`, `ARTFI_USER_AUTH_API_URL`, `ARTFI_OPERATOR_API_URL` and `ARTFI_ORACLE_READ_API_URL` bindings. Resolve their existing supported upstream paths from operations configuration.
- Browser contract/RPC/asset bindings are the actual names in `apps/web/Dockerfile` and `.env.example`: charity edition, whole collection/token/market/slug, fraction token/market/slug, governance token/governor/actions/Vault, and the established public SIN RPC route. Each marketplace deployment remains bound to its correct asset route.
- Backend persistence and object storage reuse the existing MySQL, cache and object-store configuration. Apply forward migrations `000009_native_signed_orders` and `000010_wallet_user_sessions` through the established migration procedure. Do not use schema-down operations as an application-image rollback.
- Existing operator, holder, indexer and ordinary-user server credentials remain server-side. The new ordinary-user bridge/JWT settings are empty placeholders in source. Resolve existing values through the authorized secure operations workflow; this package contains no production credentials and creates none. Browser build arguments must never contain secret values. The Qwen private attachment was not read or copied.

Follow `docs/UI_DEPLOYMENT_CONTRACT.md` at the final pinned commit. Its current contract preserves the three sections, Hoodi code and SIN/CTYun bridge roles, replacing the obsolete Sepolia and blanket no-native-trading guidance. The health route still reports chain 560048 and its existing `marketplaceMode: external-mirror` field; that field does not certify native-market availability or forbid native receipt/fraction settlement. Current technical writes are tested on isolated Hoodi fixtures; this handoff does not select or authorize a new mainnet or real-asset launch.

## Checks after the existing deployment task publishes

Record the actual deployed SHA/image digest, sanitized bindings, URLs and observed results. No production secret belongs in the report.

1. Verify `/api/health` reports the pinned `buildRevision`, service health and current chain; verify static assets, all three entry routes and mobile wallet controls. API `/healthz` alone is insufficient for persistence readiness: check a database-backed public order/portfolio read, distinguishing an actual empty account from unavailable storage.
2. Verify ordinary connect/sign-in/reload/refresh/logout and seller-bound explicit publication through the real bridge. Preserve the original sale signature; login does not authorize a transfer. Confirm public order lookup, exact links, pagination, reload and Back/Forward.
3. For the configured whole asset, verify Oracle source identity/status and clear disagreement/unavailability. A VALID result is not trading permission or proof of physical title.
4. Exercise the authorized test workflow: mint rejection/retry and receipt recovery, exact owned-NFT continuation, Vault creation, exact-token approval, deposit, issuance and holdings. Check failed logging recovery, completed-asset history, a second NFT and the configured fractionalizer continuation. Use existing test authority; no real-value transaction is authorized by this document.
5. Verify NFT/CCHS/OpenSea links and configured charity holder access, fractional trade/receipt recovery, DAO delegation/proposal/vote/queue/execute availability and the public indexed history. Indexed balances are explicitly unscaled base units; removed history retains priority.
6. Return evidence to the delivery owner for final acceptance at `io.artcch.com`. Code/CI completion does not substitute for these actual configured runtime observations.

Known recovery limits remain visible: an unresolved wallet request without a hash is not safe to repeat unless the existing exact-request chain interface proves its result; browser journals are public recovery state and confer no authority. Existing market locks are tab-scoped. Do not describe these limits as a new product stage or prerequisite.

## Related Wallet DApp handoff

The companion Wallet delivery is the DApp, pinned by the delivery owner to commit `1ccafcdd769e9c41e3531876ace1b9714fdc932b`, with deployment entry `https://xiongan.8415wallet.com/web/index.html`. Use the updated DApp package supplied with that handoff; the old `93934f9`/61-file package is superseded. This ArtFi record does not claim that the Wallet site is already deployed.
