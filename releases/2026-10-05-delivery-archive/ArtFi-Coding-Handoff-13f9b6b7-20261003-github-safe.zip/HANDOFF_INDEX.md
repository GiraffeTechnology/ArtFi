# Task 1–2 coding handoff

ArtFi coding and CI are complete at `13f9b6b774fd7ba6010cd7a500574074d1ac37d3`. Deployment is owned by the existing deployment task; neither target site is claimed as newly published here. Forward `FORWARD_TO_ARTFI_CONTROL.txt` with this package and the existing Wallet ZIP.

## ArtFi

- Repository: https://github.com/GiraffeTechnology/ArtFi
- Public target: https://io.artcch.com
- Functional changes: PR #135 (native orders and ordinary wallet sessions), PR #136 (portfolio units and confirmation replay), PR #137 (mint/Vault recovery and original role continuation).
- Final documentation: PR #138 aligns the current deployment contract. The final commit and tree are fixed in `RELEASE_MANIFEST.json`; both PR and final-main CI are successful.
- Deployment guidance: `DEPLOYMENT_HANDOFF.md` and `docs/UI_DEPLOYMENT_CONTRACT.md` at the pinned commit.
- Current application tests use isolated Hoodi fixtures. Runtime contract/API/RPC/indexer/Oracle bindings and the actual deployed workflows remain for the existing deployment task and final acceptance.

## Xiongan Wallet DApp

The deployment authority is the fixed static DApp branch, not an older generic-main or extension snapshot:

https://github.com/GiraffeTechnology/8415Wallet/tree/1ccafcdd769e9c41e3531876ace1b9714fdc932b

- Deployment branch: `deploy/xiongan-sin`.
- Deployment commit: `1ccafcdd769e9c41e3531876ace1b9714fdc932b`.
- Source commit recorded by the Wallet delivery: `763b00670752db7ed97525fca356729bbe8221d5`.
- Deployment instructions: `DEPLOY.md` at the fixed deployment commit above.
- Entry: https://xiongan.8415wallet.com/web/index.html
- Reuse the existing `Xiongan-Wallet-SIN-Handoff-763b0067.zip`, Library identity `libfile_a9559606909c81919d22f2dbffdf2123`, version 2. It has not been repackaged by the ArtFi delivery.
- ZIP SHA-256: `2781d8db19b99c1f12f337674847033186940188b0c5317b5afe722cd4b320e6`.
- Inner archive: 62 files, SHA-256 `bb66593b3f1e81ec4a319b724014bd6362d2e202a640287bedc842228b3a3187`. The delivery owner verified those static files match the fixed DApp branch.
- Wallet PR #46 head `0b91a08f` passed run https://github.com/GiraffeTechnology/8415Wallet/actions/runs/37106388300; the merge push passed run https://github.com/GiraffeTechnology/8415Wallet/actions/runs/37106488087. Both Node 22 and Node 24 executed 11 artifact tests successfully, as verified in the Wallet delivery.

The DApp contains external-EOA Ethereum mainnet/Base ETH and NFT functionality. Real provider/device behavior and deployed bindings remain unverified by this ArtFi handoff. Technical AI review is not external institutional certification and adds no new product prerequisite. No real wallet transaction or production credential handling is authorized or performed by this index.
